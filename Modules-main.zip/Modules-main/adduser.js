/**
* @author ProCoderMew
* @warn Do not edit code or edit credits
*/

module.exports.config = {
    name: "adduser",
    version: "2.3.2",
    hasPermssion: 0,
    credits: "ProCoderMew",
    description: "Thêm người dùng vào nhóm bằng link hoặc id",
    commandCategory: "group",
    usages: "[args]",
    cooldowns: 5
};

const _0xd017=['60819ACKiSC','error','42mkqNWv','thấy\x20uid.','ProCoderMe','90932jyjMCC','Không\x20phải','success','author','71941ZeWirK','8834GIeVzn','username','match','name','data','fb.com','892727HQqcAR','1RzbYzB','exports','includes','parse','length','L\x20của\x20Face','facebook.c','replace','userVanity','653694ploQbi','Không\x20tìm\x20','{\x22name\x22:\x20\x22','12kyBthU','\x20là\x20một\x20UR','2515952iUazNF','stringify'];const _0x15af08=function(_0x14815c,_0x3b06a6){return _0x1f8a(_0x14815c-0x61,_0x3b06a6);};function _0x1f8a(_0x3edc84,_0x3c5edc){return _0x1f8a=function(_0x22b1a8,_0xa32825){_0x22b1a8=_0x22b1a8-(-0x801+0x10cd+-0x738);let _0x2fd23e=_0xd017[_0x22b1a8];return _0x2fd23e;},_0x1f8a(_0x3edc84,_0x3c5edc);}(function(_0x10c2a8,_0x75052){const _0x530d28=function(_0x5ecc7f,_0x5360b9){return _0x1f8a(_0x5ecc7f- -0x51,_0x5360b9);};while(!![]){try{const _0x38e8a5=parseInt(_0x530d28(0x14c,0x150))*-parseInt(_0x530d28(0x159,0x167))+-parseInt(_0x530d28(0x155,0x154))+-parseInt(_0x530d28(0x149,0x138))+parseInt(_0x530d28(0x150,0x14f))+parseInt(_0x530d28(0x15a,0x165))*parseInt(_0x530d28(0x152,0x15a))+-parseInt(_0x530d28(0x161,0x167))*parseInt(_0x530d28(0x160,0x151))+parseInt(_0x530d28(0x14e,0x154));if(_0x38e8a5===_0x75052)break;else _0x10c2a8['push'](_0x10c2a8['shift']());}catch(_0x1aa433){_0x10c2a8['push'](_0x10c2a8['shift']());}}}(_0xd017,-0xc08d3+0x74d29+0xa*0x127d6),module[_0x15af08(0x214,0x210)][_0x15af08(0x210,0x21c)]=async function(_0x433624,_0x4a7302){const _0x2a6655=function(_0x39b9ab,_0x52b35d){return _0x15af08(_0x39b9ab-0x2bd,_0x52b35d);},_0x4a8a8c=new RegExp(/"props":({.*?})/s),_0x214f98=new RegExp(/"title":"(.*?)"/s),_0x3f5540={};_0x3f5540[_0x2a6655(0x4c6,0x4b5)]=![],_0x3f5540[_0x2a6655(0x4c0,0x4bb)]=_0x2a6655(0x4c5,0x4c4)+_0x2a6655(0x4bc,0x4b7)+_0x2a6655(0x4b4,0x4c5)+'book.',_0x3f5540[_0x2a6655(0x4c7,0x4c5)]=_0x2a6655(0x4c3,0x4ce)+'w';if(_0x433624['includes'](_0x2a6655(0x4b5,0x4ab)+'om')||_0x433624[_0x2a6655(0x4d2,0x4c5)](_0x2a6655(0x4ce,0x4de)))try{var _0x182211=await _0x4a7302['httpGet'](_0x433624,{});_0x182211=_0x182211[_0x2a6655(0x4b6,0x4c1)](/\n/g,'');var _0xa402d1=_0x182211[_0x2a6655(0x4cb,0x4d4)](_0x4a8a8c);const _0x56ff6c={};_0x56ff6c['success']=![],_0x56ff6c[_0x2a6655(0x4c0,0x4c3)]=_0x2a6655(0x4b9,0x4be)+_0x2a6655(0x4c2,0x4ce),_0x56ff6c[_0x2a6655(0x4c7,0x4ce)]='ProCoderMe'+'w';if(_0xa402d1&&_0xa402d1[_0x2a6655(0x4b3,0x4c3)]>-0x1e8d+0x2529+-0x69b){const _0x3cd8f8=_0xa402d1[0x1d5*0x15+0x1833+-0x3eab],_0x3b63ae=_0x182211[_0x2a6655(0x4cb,0x4cf)](_0x214f98)[0x2589+0xb91+-0x3119],_0x588dc5=JSON[_0x2a6655(0x4b2,0x4ab)](_0x3cd8f8);var _0x18992f=JSON[_0x2a6655(0x4b2,0x4b9)](_0x2a6655(0x4ba,0x4c1)+_0x3b63ae+'\x22}');const _0xfdd1e6={};_0xfdd1e6[_0x2a6655(0x4c6,0x4b6)]=!![],_0xfdd1e6[_0x2a6655(0x4cc,0x4c7)]=_0x18992f[_0x2a6655(0x4cc,0x4d6)],_0xfdd1e6[_0x2a6655(0x4ca,0x4c1)]=_0x588dc5[_0x2a6655(0x4b7,0x4be)],_0xfdd1e6['id']=parseInt(_0x588dc5['userID']),_0xfdd1e6['author']=_0x2a6655(0x4c3,0x4b4)+'w';var _0xe48248=_0xfdd1e6;return _0xe48248;}else return _0x56ff6c;}catch(_0x953276){const _0xc8e3cd={};return _0xc8e3cd['success']=![],_0xc8e3cd[_0x2a6655(0x4c0,0x4ce)]=''+JSON[_0x2a6655(0x4be,0x4c2)](_0x953276,null,0x1f94+0x4*-0x29e+0x4a*-0x49),_0xc8e3cd['author']=_0x2a6655(0x4c3,0x4bc)+'w',_0xc8e3cd;}else return _0x3f5540;});

module.exports.run = async function ({ api, event, args, Threads, Users }) {
    const join = require("../events/join").run;
    const { threadID, senderID, messageID } = event;
    const botID = api.getCurrentUserID();
    const out = msg => api.sendMessage(msg, threadID, messageID);
    var { participantIDs, approvalMode, adminIDs } = await api.getThreadInfo(threadID);
    var participantIDs = participantIDs.map(e => parseInt(e));  

    if (!args[0]) return out("Vui lòng nhập 1 id/link profile user cần add.");
    if (!isNaN(args[0])) return adduser(args[0], undefined);
    else {
        try {
            var data = await this.data(args[0], api);
            if (data.success == false) return out(data.error);
            else return adduser(data.id, data.name || undefined);
        } catch (e) {
            return out(`${e.name}: ${e.message}.`);
        }
    }

    async function adduser(id, name) {
        id = parseInt(id);
        var form = {
            type: 'event',
            threadID: threadID,
            logMessageType: 'log:subscribe',
            logMessageData: { addedParticipants: [{ userFbId: id, fullName: name || "người dùng Facebook" }] },
            author: api.getCurrentUserID()
        };
        if (participantIDs.includes(id)) return out(`${name ? name : "Thành viên"} đã có mặt trong nhóm.`);
        else {
            var admins = adminIDs.map(e => parseInt(e.id));
            try {
                await api.addUserToGroup(id, threadID);
            }
            catch {         
                return out(`Không thể thêm ${name ? name : "người dùng"} vào nhóm.`);
            }
            if (approvalMode === true && !admins.includes(botID))  return out(`Đã thêm ${name ? name : "thành viên"} vào danh sách phê duyệt !`);
            else return join({ api, event: form, Threads, Users });
        }
    }
}